package com.hcl.pp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.pp.beans.Pet;
import com.hcl.pp.beans.User;
import com.hcl.pp.services.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;
	
	@PostMapping("/add")
	public ResponseEntity<String> addUsers(@RequestBody User user){
	String message= userService.addUsers(user);
	return new ResponseEntity<String>(message, HttpStatus.CREATED);
	}
	@PostMapping("/buyPet{petId}/{userId}")
	public ResponseEntity<String> buyPets(@PathVariable int petId,int userId){
	String message= userService.buyPets(petId, userId);
	return new ResponseEntity<String>(message, HttpStatus.CREATED);
	}
	@GetMapping("/myPets{userId}")
	public List<Pet> getMyPets(@PathVariable int userId){
		List<Pet> petsList = null;
		petsList = userService.myPets(userId);
		
		return petsList;
	}
	

}
