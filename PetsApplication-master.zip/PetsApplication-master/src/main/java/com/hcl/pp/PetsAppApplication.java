package com.hcl.pp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetsAppApplication.class, args);
	}

}
